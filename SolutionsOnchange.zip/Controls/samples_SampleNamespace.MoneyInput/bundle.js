/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./MoneyInput/index.ts"
/*!*****************************!*\
  !*** ./MoneyInput/index.ts ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   MoneyInput: () => (/* binding */ MoneyInput)\n/* harmony export */ });\nclass MoneyInput {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._value = null;\n    this._formattedValue = \"\";\n    this._lastResetValue = false;\n    // Internal state to track decimals\n    this._decimals = 2;\n    // Empty\n  }\n  init(context, notifyOutputChanged, state, container) {\n    try {\n      this._notifyOutputChanged = notifyOutputChanged;\n      this._context = context;\n      this._container = container;\n      // --- CRITICAL FIX FOR HEIGHT ---\n      context.mode.trackContainerResize(true);\n      this._container.classList.add(\"MoneyInput\");\n      this._container.style.display = \"flex\";\n      this._container.style.alignItems = \"stretch\";\n      this._container.style.overflow = \"hidden\";\n      // Create Container\n      this._inputContainer = document.createElement(\"div\");\n      this._inputContainer.classList.add(\"money-input-container\");\n      // Create Currency Symbol Span\n      this._currencySpan = document.createElement(\"span\");\n      this._currencySpan.classList.add(\"money-input-currency\");\n      // Create Input Element\n      this._inputElement = document.createElement(\"input\");\n      this._inputElement.type = \"text\";\n      this._inputElement.classList.add(\"money-input-field\");\n      // Attach event listeners prevent memory leak by saving bound reference\n      this._inputHandler = this.onInput.bind(this);\n      this._blurHandler = this.onBlur.bind(this);\n      this._inputElement.addEventListener(\"input\", this._inputHandler);\n      this._inputElement.addEventListener(\"blur\", this._blurHandler);\n      // Append to container\n      this._inputContainer.appendChild(this._currencySpan);\n      this._inputContainer.appendChild(this._inputElement);\n      this._container.appendChild(this._inputContainer);\n    } catch (e) {\n      console.error(\"MoneyInput PCF init error:\", e);\n    }\n  }\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;\n    try {\n      this._context = context;\n      var {\n        parameters\n      } = context;\n      // --- 1. Settings & Styles ---\n      this._decimals = (_b = (_a = parameters.DecimalPlaces) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : 2;\n      this._currencySpan.innerText = ((_c = parameters.CurrencySymbol) === null || _c === void 0 ? void 0 : _c.raw) || \"$\";\n      // --- DIMENSIONAMIENTO DIRECTO EN PX ---\n      var allocatedW = context.mode.allocatedWidth;\n      var allocatedH = context.mode.allocatedHeight;\n      if (allocatedW > 0) {\n        this._inputContainer.style.width = \"\".concat(allocatedW, \"px\");\n      } else {\n        this._inputContainer.style.width = \"100%\";\n      }\n      if (allocatedH > 0) {\n        this._inputContainer.style.height = \"\".concat(allocatedH, \"px\");\n      } else {\n        this._inputContainer.style.height = \"100%\";\n      }\n      // Apply neutral base styles\n      this._inputContainer.style.borderRadius = \"10px\";\n      this._inputContainer.style.backgroundColor = \"#FFFFFF\";\n      this._inputContainer.style.borderColor = \"#000000\";\n      this._inputContainer.style.borderWidth = \"1px\";\n      this._inputContainer.style.borderStyle = \"solid\";\n      this._inputElement.style.fontSize = \"14px\";\n      this._inputElement.style.color = \"#000000\";\n      this._currencySpan.style.fontSize = \"14px\";\n      this._currencySpan.style.color = \"#000000\";\n      // Quitar bordes y fondos del input\n      this._inputElement.style.backgroundColor = \"transparent\";\n      this._inputElement.style.border = \"none\";\n      this._inputContainer.style.paddingLeft = \"8px\";\n      this._inputContainer.style.paddingRight = \"8px\";\n      this._inputContainer.style.paddingTop = \"0px\";\n      this._inputContainer.style.paddingBottom = \"0px\";\n      this._inputElement.style.textAlign = \"right\";\n      // Remover estilos de posicion absoluta del TS para volver al flow normal\n      this._currencySpan.style.position = \"\";\n      this._currencySpan.style.left = \"\";\n      this._inputElement.style.paddingLeft = \"0px\";\n      this._inputElement.style.paddingRight = \"4px\";\n      // --- 2. Display Mode Logic ---\n      // 0=Edit, 1=View, 2=Disabled\n      var displayMode = (_e = (_d = parameters.ComponentDisplayMode) === null || _d === void 0 ? void 0 : _d.raw) !== null && _e !== void 0 ? _e : 0;\n      if (displayMode === 1) {\n        // View\n        this._inputElement.readOnly = true;\n        this._inputElement.disabled = false;\n        this._inputContainer.classList.add(\"view-mode\");\n        this._inputContainer.classList.remove(\"disabled-mode\");\n      } else if (displayMode === 2) {\n        // Disabled\n        this._inputElement.readOnly = false;\n        this._inputElement.disabled = true;\n        this._inputContainer.classList.add(\"disabled-mode\");\n        this._inputContainer.classList.remove(\"view-mode\");\n      } else {\n        // Edit\n        this._inputElement.readOnly = false;\n        this._inputElement.disabled = false;\n        this._inputContainer.classList.remove(\"view-mode\", \"disabled-mode\");\n      }\n      // --- 3. Reset Flow ---\n      var currentReset = ((_f = parameters.TriggerReset) === null || _f === void 0 ? void 0 : _f.raw) === true;\n      if (currentReset && !this._lastResetValue) {\n        // Trigger Reset -> Load Default Value\n        var defaultVal = (_h = (_g = parameters.DefaultValue) === null || _g === void 0 ? void 0 : _g.raw) !== null && _h !== void 0 ? _h : null;\n        this.updateInternalValue(defaultVal);\n        this._lastResetValue = true;\n        // EVITAR CRASH FATAL: No se puede llamar a _notifyOutputChanged sincronamente en updateView\n        setTimeout(() => {\n          var _a, _b;\n          this._notifyOutputChanged();\n          (_b = (_a = this._context.events) === null || _a === void 0 ? void 0 : _a.OnResetTriggered) === null || _b === void 0 ? void 0 : _b.call(_a);\n        }, 0);\n      } else if (!currentReset) {\n        this._lastResetValue = false;\n        // If not resetting AND not currently typing, update from external 'MoneyValue' bound property\n        // We check document.activeElement so we don't overwrite user's intermediate typing\n        if (document.activeElement !== this._inputElement) {\n          // Determine if we use bound MoneyValue or DefaultValue (on first load)\n          if (((_j = parameters.MoneyValue) === null || _j === void 0 ? void 0 : _j.raw) != null) {\n            this.updateInternalValue(parameters.MoneyValue.raw);\n          } else if (((_k = parameters.DefaultValue) === null || _k === void 0 ? void 0 : _k.raw) != null && this._value === null) {\n            this.updateInternalValue(parameters.DefaultValue.raw);\n            // EVITAR CRASH FATAL\n            setTimeout(() => this._notifyOutputChanged(), 0);\n          } else {\n            this.updateInternalValue(null);\n          }\n        }\n      }\n    } catch (e) {\n      console.error(\"MoneyInput PCF updateView error:\", e);\n    }\n  }\n  getOutputs() {\n    try {\n      return {\n        MoneyValue: this._value !== null ? this._value : undefined,\n        FormattedValue: this._formattedValue\n      };\n    } catch (e) {\n      console.error(\"MoneyInput PCF getOutputs error:\", e);\n      return {};\n    }\n  }\n  destroy() {\n    try {\n      this._inputElement.removeEventListener(\"input\", this._inputHandler);\n      this._inputElement.removeEventListener(\"blur\", this._blurHandler);\n    } catch (e) {\n      console.error(\"MoneyInput PCF destroy error:\", e);\n    }\n  }\n  // --- Private Helper Methods ---\n  onInput(event) {\n    var _a, _b;\n    var input = event.target;\n    var cursorPosition = input.selectionStart || 0;\n    var originalLength = input.value.length;\n    // 1. Sanitize: Allow only digits and a single decimal point\n    var sanitized = input.value.replace(/[^0-9.]/g, '');\n    var parts = sanitized.split('.');\n    if (parts.length > 2) {\n      sanitized = parts[0] + '.' + parts.slice(1).join('');\n      parts = sanitized.split('.');\n    }\n    // 1.5 Limit the decimal places during typing\n    if (parts.length === 2 && parts[1].length > this._decimals) {\n      parts[1] = parts[1].substring(0, this._decimals);\n      sanitized = parts[0] + '.' + parts[1];\n    }\n    // 2. Format with commas\n    var formatted = this.formatNumberString(sanitized);\n    // 3. Re-apply to input\n    input.value = formatted;\n    // 4. Reposition Cursor\n    var newLength = formatted.length;\n    cursorPosition = cursorPosition + (newLength - originalLength);\n    input.setSelectionRange(cursorPosition, cursorPosition);\n    // 5. Update internal values and notify Canvas App\n    var parsedValue = parseFloat(sanitized);\n    this._value = isNaN(parsedValue) ? null : parsedValue;\n    this._formattedValue = formatted;\n    this._notifyOutputChanged();\n    (_b = (_a = this._context.events) === null || _a === void 0 ? void 0 : _a.OnMoneyValueChange) === null || _b === void 0 ? void 0 : _b.call(_a);\n  }\n  onBlur(event) {\n    var _a, _b;\n    // Enforce decimal places when the user leaves the field\n    if (this._value !== null) {\n      this.updateInternalValue(this._value);\n      this._notifyOutputChanged();\n      (_b = (_a = this._context.events) === null || _a === void 0 ? void 0 : _a.OnMoneyValueChange) === null || _b === void 0 ? void 0 : _b.call(_a);\n    }\n  }\n  updateInternalValue(val) {\n    if (val === null) {\n      this._value = null;\n      this._formattedValue = \"\";\n      this._inputElement.value = \"\";\n    } else {\n      // Apply decimals and format\n      var fixedStr = val.toFixed(this._decimals);\n      this._value = parseFloat(fixedStr); // Sync internal true value with rounding\n      this._formattedValue = this.formatNumberString(fixedStr);\n      this._inputElement.value = this._formattedValue;\n    }\n  }\n  formatNumberString(valStr) {\n    if (!valStr) return \"\";\n    var parts = valStr.split('.');\n    parts[0] = parts[0].replace(/\\B(?=(\\d{3})+(?!\\d))/g, \",\");\n    return parts.join('.');\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MoneyInput/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./MoneyInput/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SampleNamespace.MoneyInput', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MoneyInput);
} else {
	var SampleNamespace = SampleNamespace || {};
	SampleNamespace.MoneyInput = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MoneyInput;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}